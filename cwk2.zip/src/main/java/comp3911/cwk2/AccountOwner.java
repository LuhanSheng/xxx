package comp3911.cwk2;

public class AccountOwner {
  private Integer id;
  private String name;

  public Integer getId() { return id; }
  public String getName() { return name; }

  public void setId(Integer value) { id = value; }
  public void setName(String value) { name = value; }
}
